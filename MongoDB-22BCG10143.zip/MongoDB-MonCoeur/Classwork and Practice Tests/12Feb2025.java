// Software installation and task submission


package practice1;

public class Testing1{
  public static void main(String[] args){
    System.out.println("Radhe Radhe");
  }
}
