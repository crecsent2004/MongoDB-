-- commonds of powershel and outputs:
-- show databases
-- admin                  40.00 KiB
-- config                 48.00 KiB
-- local                  96.00 KiB
-- orphanage_management  384.00 KiB
-- test                    8.00 KiB
-- vit                    40.00 KiB
-- use admin
-- switched to db admin
-- use vit
-- switched to db vit
-- show databases
-- admin                  40.00 KiB
-- config                 48.00 KiB
-- local                  96.00 KiB
-- orphanage_management  384.00 KiB
-- test                    8.00 KiB
-- vit                    40.00 KiB


-- Codes


