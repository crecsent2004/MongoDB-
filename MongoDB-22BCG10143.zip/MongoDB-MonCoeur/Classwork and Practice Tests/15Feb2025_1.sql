create database saturday;
use saturday;
create table 'user'(
  'sl_no' INT(5) NULL DEFAULT NULL,
  'name' VARCHAR(100) NULL DEFAULT NULL,
  'email' VARCHAR(100) NULL DEFAULT NULL
);

select * from user;


create Database crud;
use crud;

create table user1(
  sl_no INT NULL DEFAULT NULL,
  name VARCHAR(100) NULL DEFAULT NULL,
  email VARCHAR(100) NULL DEFAULT NULL
  );

select * from user1
