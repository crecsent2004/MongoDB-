create database friday;
use friday;
show tables from friday;

create table student(id int, name varchar(20), location varchar(20));
insert into student values (101, 'Shubham','Samastipur'),(102,'Joy','Kolkata');

select *from student;

