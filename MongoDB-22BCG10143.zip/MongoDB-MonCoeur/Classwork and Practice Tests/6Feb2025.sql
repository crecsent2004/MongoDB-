create database org;

show databases;


use org123;
create table Persons(
ID int NOT NULL,
LastName varchar(255) NOT NULL,
FirstName varchar(255) NOT NULL,
Age int
);

desc persons;
ALTER TABLE Persons
modify AGE INT NOT NULL;

CREATE TABLE Persons1(
ID int Primary key,
LastName varchar(255) NOT NULL unique,
FirstName varchar(255) NOT NULL unique,
Age int
);
desc persons1;


